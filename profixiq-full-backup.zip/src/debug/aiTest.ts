import { OpenAIStream, StreamingTextResponse } from 'ai';

console.log('OpenAIStream type:', typeof OpenAIStream);
console.log('StreamingTextResponse type:', typeof StreamingTextResponse);