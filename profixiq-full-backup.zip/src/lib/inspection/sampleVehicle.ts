const sampleVehicle = {
  id: 'vehicle-123',
  year: 2020,
  make: 'Ford',
  model: 'F-150',
  vin: '1FTFW1E58LFA00001',
  licensePlate: 'ABC123',
  mileage: 123456,
  color: 'White',
};

export default sampleVehicle;