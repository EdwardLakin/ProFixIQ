'use client';

import React from 'react';
import ProFixIQLanding from '@components/ProFixIQLanding';

export default function Home() {
  return <ProFixIQLanding />;
}