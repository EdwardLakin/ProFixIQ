// src/test/Test.tsx

export default function Test() {
  const obj = { x: 1, y: 2 };
  return (
    <div>
      <p>{obj.x}</p>
    </div>
  );
}
