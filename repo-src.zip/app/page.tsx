import ProFixIQLanding from "@shared/components/ProFixIQLanding";

export default function Home() {
  return <ProFixIQLanding />;
}
