"use client";

export default function TechDashboard() {
  return (
    <div className="p-6 text-white font-blackops">
      <h1 className="text-2xl text-orange-500">Technician Dashboard</h1>
      <p className="mt-4">
        Welcome, tech! View your jobs and punch in/out here.
      </p>
    </div>
  );
}
