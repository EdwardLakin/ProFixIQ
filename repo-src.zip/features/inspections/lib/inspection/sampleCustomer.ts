const sampleCustomer = {
  id: "customer-456",
  firstName: "John",
  lastName: "Doe",
  phone: "555-123-4567",
  email: "john.doe@example.com",
  address: "123 Main St",
  city: "Calgary",
  province: "AB",
  postalCode: "T1X 1X1",
};

export default sampleCustomer;
