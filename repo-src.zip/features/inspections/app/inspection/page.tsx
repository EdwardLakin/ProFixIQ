// app/inspection/page.tsx
import InspectionMenuClient from "./InspectionMenuClient";

export default function InspectionMenuPage() {
  return <InspectionMenuClient />;
}
